<div class="list-item-desc">
	<div class="list-item-desc-title">
		<a href="%IMAGE_URL_VIEWER%" class="list-item-desc-title-link" data-text="image-title-truncated" data-content="image-link" title="%IMAGE_TITLE%">%IMAGE_TITLE%</a><span class="display-block font-size-small"><?php _se('Uploaded by private'); ?></span>
	</div>
	%tpl_list_item/item_like% 
</div>