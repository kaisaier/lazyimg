<ul class="list-item-image-tools" data-action="list-tools">
	<li class="tool-select" data-action="select">
		<span data-icon-selected="icon-ok" data-icon-unselected="icon-checkbox-unchecked" class="btn-icon icon-checkbox-unchecked" title="<?php _se('Select'); ?>"></span>
		<span class="label label-select"><?php _se('Select'); ?></span>
	</li>
</ul>